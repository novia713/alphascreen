# alphascreen
Alphascreen is an alphabetic homescreen for FirefoxOS
